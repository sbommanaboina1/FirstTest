/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { StatusComponent } from './status.component';

describe('Component: Status', () => {
  it('should create an instance', () => {
    let component = new StatusComponent();
    expect(component).toBeTruthy();
  });
});
