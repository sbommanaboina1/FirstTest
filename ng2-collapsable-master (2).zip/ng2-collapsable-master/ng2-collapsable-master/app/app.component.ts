import { Component } from '@angular/core';
import {Paho} from 'mqttws31'
@Component({
  selector: 'my-app',
  template: `
    <div ng2-collapsable
      selected="js"
      selected-index-class="selected"
      selected-contents-class="selected">
      <div index="html">HTML</div>
      <div contents="html">HTML {{foo}}</div>
      
      <div index="js">Javascript</div>
      <div contents="js">Javascript {{bar}}</div>
      
      <div index="css">Css</div>
      <div contents="css">Style Sheet</div>
    </div>
  `,
  styles: [`
  `]
})
export class AppComponent {
  private _client: Paho.MQTT.Client;
  foo = 'my test foo';
  bar = 'my test bar';
  public constructor() {
    debugger;
    this._client = new Paho.MQTT.Client("host", 80, "path", "clientId");
  }
}
