﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class AutoCompleteModel
    {
        public string Symbol { get; set; }
        public string SymbolDescription { get; set; }

        public int Option { get; set; }
    }
}