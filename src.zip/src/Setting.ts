
import {List,Record} from 'immutable';

const SettingRecord = Record({
    id: 0,
    description: "",
    completed: false
});

export class Setting extends SettingRecord {

    id:number;
    description:string;
    completed: boolean;

    constructor(props) {
        super(props);
    }

}