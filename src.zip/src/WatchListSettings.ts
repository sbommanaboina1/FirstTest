import {Component, Input, Output, EventEmitter, Inject} from 'angular2/core';
import {Setting} from "./Setting";
import {List} from 'immutable';
import {Observer} from "rxjs/Observer";
import {Observable} from "rxjs/Observable";
import {SettingService} from "./state/SettingService";


@Component({
    selector: 'todo-list',
    template: `

        <section id="main">
            <ul id="todo-list">
                <li *ngFor="#todo of settingservice.todos | async" [ngClass]="{completed: todo.completed}">
                    <div class="view">
                        <input class="toggle" type="checkbox" (change)="onToggleTodo(todo)" [checked]="todo.completed">
                        <label>{{todo.description}}</label>
                        <button class="destroy" (click)="delete(todo)"></button>
                    </div>
                </li>
            </ul>
        </section>
    `
})
export class WatchListSettings {

    constructor(private settingservice: SettingService) {

  

    }


    onToggleTodo(todo: Setting) {
        this.settingservice.toggleTodo(todo);
    }

    delete(todo:Setting) {
        this.settingservice.deleteTodo(todo);
    }

}