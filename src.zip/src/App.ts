
/// <reference path="../node_modules/immutable/dist/immutable.d.ts" />

import "angular2/bundles/angular2-polyfills";
import {Component, provide, Inject} from "angular2/core";
import {HTTP_PROVIDERS} from "angular2/http";
import {Header} from "./Header";
import {WatchListSettings} from "./WatchListSettings";
import {Setting} from "./Setting";
import {Footer} from "./Footer";
import {List} from "immutable";
import {bootstrap} from "angular2/platform/browser";
import {Subject} from "rxjs/Subject";
import {Observable} from "rxjs/Observable";
import {Observer} from "rxjs/Observer";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/scan';
import 'rxjs/add/operator/share';
import {SettingBackendService} from "./SettingBackendService";
import {SettingService} from "./state/SettingService";
import {UiStateStore} from "./state/UiStateStore";
import {UiState} from "./state/ui-state";

@Component({
    selector: 'app',
    directives: [Header, WatchListSettings, Footer],
    template: `
        <div>
            <section id="todoapp">

                <todo-header (todo)="onAddTodo($event)"></todo-header>

                <todo-list></todo-list>

                <todo-footer [hidden]="(size | async) === 0" [count]="size | async"></todo-footer>

            </section>
            <footer id="info">
                <p>{{uiStateMessage | async}}</p>
                <p>Add, Remove and Complete TODOs</p>
            </footer>
        </div>
    `
})
export class App {

    constructor(private settingService: SettingService, private uiStateStore: UiStateStore) {
      for (var index = 0; index < 2; index++) {
           let settingId=Math.random();
           let newSetting = new Setting({id:settingId, description:"Random Setting"+settingId});
           // settingService.addTodo(newSetting);
            this.uiStateStore.startBackendAction('Saving Todo...');
        console.log()
        this.settingService.addTodo(newSetting)
            .subscribe(
                res => {},
                err => {
                    this.uiStateStore.endBackendAction();
                }
            );
            console.log("created & subscribed for new setting with Id: "+ newSetting.id);
            //newSetting.completed=true;
            settingService.toggleTodo(newSetting);
            console.log("updated new setting with Id: "+ newSetting.id);
            settingService.deleteTodo(newSetting);
            console.log("deleted new setting with Id:"+ newSetting.id);
            
        }
    }

    get size() {
        return this.settingService.todos.map((todos: List<Setting>) => todos.size);
    }

    get uiStateMessage() {
        return this.uiStateStore.uiState.map((uiState: UiState) => uiState.message);
    }


    onAddTodo(description) {
        let newTodo = new Setting({id:Math.random(), description});
        this.uiStateStore.startBackendAction('Saving Todo...');
        console.log()
        this.settingService.addTodo(newTodo)
            .subscribe(
                res => {},
                err => {
                    this.uiStateStore.endBackendAction();
                }
            );
    }

}

bootstrap(App, [
    HTTP_PROVIDERS,
    SettingBackendService,
    SettingService,
    UiStateStore
]);