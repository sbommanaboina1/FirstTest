
import {Injectable} from "angular2/core";
import {SettingBackendService} from "../SettingBackendService";
import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Subject";
import {Setting} from "../Setting";
import {List} from 'immutable';
import {asObservable} from "./asObservable";
import {BehaviorSubject} from "rxjs/Rx";

@Injectable()
export class SettingService {

    private _watchListSettings: BehaviorSubject<List<Setting>> = new BehaviorSubject(List([]));

    constructor(private settingBackendService: SettingBackendService) {
        this.loadInitialData();
    }

    get todos() {
        return asObservable(this._watchListSettings);
    }

    loadInitialData() {
        this.settingBackendService.getAllTodos()
            .subscribe(
                res => {
                    let todos = (<Object[]>res.json()).map((todo: any) =>
                        new Setting({id:todo.id, description:todo.description,completed: todo.completed}));

                    this._watchListSettings.next(List(todos));
                },
                err => console.log("Error retrieving Todos")
            );

    }

    addTodo(newTodo:Setting):Observable {

        let obs = this.settingBackendService.saveTodo(newTodo);

        obs.subscribe(
                res => {
                    this._watchListSettings.next(this._watchListSettings.getValue().push(newTodo));
                });

        return obs;
    }

    toggleTodo(toggled:Setting): Observable {
        let obs: Observable = this.settingBackendService.toggleTodo(toggled);

        obs.subscribe(
            res => {
                let todos = this._watchListSettings.getValue();
                let index = todos.findIndex((todo: Setting) => todo.id === toggled.id);
                let todo:Setting = todos.get(index);
                this._watchListSettings.next(todos.set(index, new Setting({id:toggled.id, description:toggled.description, completed:!toggled.completed}) ));
            }
        );

        return obs;
    }


    deleteTodo(deleted:Setting): Observable {
        let obs: Observable = this.settingBackendService.deleteTodo(deleted);

        obs.subscribe(
                res => {
                    let todos: List<Setting> = this._watchListSettings.getValue();
                    let index = todos.findIndex((todo) => todo.id === deleted.id);
                    this._watchListSettings.next(todos.delete(index));

                }
            );

        return obs;
    }


}
