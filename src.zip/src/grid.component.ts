/// <reference path="../typings/slickgrid.d.ts" />
import "angular2/bundles/angular2-polyfills";
import {Component, provide, Inject,Input, ElementRef} from "angular2/core";
import {HTTP_PROVIDERS} from "angular2/http";
import {Header} from "./Header";
import {WatchListSettings} from "./WatchListSettings";
import {Setting} from "./Setting";
import {Footer} from "./Footer";
import {List} from "immutable";
import {bootstrap} from "angular2/platform/browser";
import {Subject} from "rxjs/Subject";
import {Observable} from "rxjs/Observable";
import {Observer} from "rxjs/Observer";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/scan';
import 'rxjs/add/operator/share';
import {SettingBackendService} from "./SettingBackendService";
import {SettingService} from "./state/SettingService";
import {UiStateStore} from "./state/UiStateStore";
import {UiState} from "./state/ui-state";

@Component({
    selector: 'grid',template: `<div id="grid" style="width:600px;height:500px;"></div>`,
    directives: [Header, WatchListSettings, Footer],
  })
export class GridComponent {
   @Input() private conf;
   
private table;
private data: any[];
private columns: any[];
private grid: any;
private options= {
enableCellNavigation: true,
 enableColumnReorder: false
};
       constructor(@Inject(ElementRef) private elementReference: ElementRef){
           this.columns.length=1;
           debugger;
           this.grid = new Slick.Grid("#myGrid", this.data, this.columns, this.options);
       }
       
       private ngOnInit(){
           var self = this;
           this.columns.push({id: "title", name: "Title", field: "title"});
           
           var options = {editable:false,enableAddRow:false,enableCellNavigation: true, rowHeight: 25};
           this.data[0]= {title:"test"};
           this.table = new Slick.Grid("#grid",this.data,this.columns,options);
       }
       
      public push(row){
          var r = this.data.length;
          this.data[r] = {};
          //for(var c=0;c<this.columns.length; c++)this.data[r][this.columsn[c].field]= 
          this.table.invlidateRow(r);
          this.table.updateRowCOunt();
          this.table.render();
      }

      public reset(data){
          this.conf.dataModel.data = data;
      }
}

bootstrap(GridComponent, [
    HTTP_PROVIDERS,
    SettingBackendService,
    SettingService,
    UiStateStore
]);