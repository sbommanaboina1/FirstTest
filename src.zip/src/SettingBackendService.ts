
import {Injectable,Inject} from 'angular2/core';
import  {Http,Headers,URLSearchParams} from 'angular2/http';
import {Setting} from "./Setting";
import {List} from 'immutable';
import {Observable} from "rxjs/Observable";


@Injectable()
export class SettingBackendService {

    http:Http;

    constructor(http:Http)  {
        this.http = http;
    }

    getAllTodos() {
        return this.http.get('/todo');
    }

    saveTodo(newTodo: Setting) : Observable<List<Setting>> {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json; charset=utf-8');

        return this.http.post('/todo', JSON.stringify(newTodo.toJS()),{headers}).share();
    }

    deleteTodo(deletedTodo: Setting) {
        let params = new URLSearchParams();
        params.append('id', '' + deletedTodo.id );

        return this.http.delete('/todo', {search: params}).share();
    }


    toggleTodo(toggled: Setting) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return this.http.put('/todo', JSON.stringify(toggled.toJS()),{headers}).share();
    }

}